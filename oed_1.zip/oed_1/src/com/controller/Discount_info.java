package com.controller;

public class Discount_info 
{
	private String course_id;
	private Double half_yearly;
	private Double annual;
	public Discount_info(String course_id, Double half_yearly, Double annual) {
		super();
		this.course_id = course_id;
		this.half_yearly = half_yearly;
		this.annual = annual;
	}
	public Discount_info() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getCourse_id() {
		return course_id;
	}
	public void setCourse_id(String course_id) {
		this.course_id = course_id;
	}
	public Double getHalf_yearly() {
		return half_yearly;
	}
	public void setHalf_yearly(Double half_yearly) {
		this.half_yearly = half_yearly;
	}
	public Double getAnnual() {
		return annual;
	}
	public void setAnnual(Double annual) {
		this.annual = annual;
	}
	
	
}

