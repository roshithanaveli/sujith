package com.controller;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.ConsoleHandler;
import java.util.logging.FileHandler;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Schedule
 */
@WebServlet("/Schedule")
public class Schedule extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private static Logger log = Logger.getLogger(Schedule.class.getName());
    @Override
    public void init() throws ServletException 
{
          log.setLevel(Level.FINE);
          log.addHandler(new ConsoleHandler());
          try {
               File dir = new File("D:\\Logs");
               if(!dir.exists())
               {
                    dir.mkdir();
               }
               
               File file = new File(dir,"logger.schedule");
               Handler fileHandler = new FileHandler(file.getAbsolutePath(), 2000, 5);
               log.addHandler(fileHandler);
       } catch (SecurityException | IOException e1) {
           System.out.println("Exception on creating log file");
          e1.printStackTrace();
    }
}
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Schedule() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession ses=request.getSession();
		SimpleDateFormat sdf =new SimpleDateFormat("dd/MM/yyyy");
		String course_id=request.getParameter("course_name"); 
		Integer semester=Integer.parseInt(request.getParameter("sem")); 
		Date start_date=null; 
		Date end_date=null;
		try {
			start_date=sdf.parse(request.getParameter("start_date"));
			 end_date=sdf.parse(request.getParameter("end_date"));    
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
		
		Schedule_master s=new Schedule_master(course_id, semester, start_date, end_date);
		int i=Schedule_master_DAO.insertschedule_master(s);
		String msg="";
		if(i==1)
		msg="<h1><font color='green'> Exam Schedule details has been successfully inserted </font></h1>";
		else
			msg="<h1><font color='red'>Error in scheduling Exam details </font></h1>";
			
		log.warning(msg);
			ses.setAttribute("msg1",msg);
		RequestDispatcher rd= request.getRequestDispatcher("end1.jsp");
		rd.forward(request, response);
		
	}

}
