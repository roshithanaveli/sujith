package com.controller;


import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.text.*;
import java.util.concurrent.ExecutionException;
public class Stream_info_DAO {
private static Connection con;
private static Statement stmt;
private static ResultSet rs;

//static String i1sqlj="insert into customer value(?,?,?,?,?)";

static PreparedStatement ps=null;


public static List<Stream_info> getstream_info()
{
try{
		
		String url ="jdbc:mysql://localhost:3306/onlineeductionalportal";
		Class.forName("com.mysql.jdbc.Driver");
		con =DriverManager.getConnection(url,"root","root");
		stmt= con.createStatement();
	}catch(Exception ex){
	System.out.println("Open Exception-Stream_info");	
	}
	List<Stream_info>local =new ArrayList<>();
	try{
	String query ="Select * from stream_info";
		rs=stmt.executeQuery(query);
		
while(rs.next())
{
String course_id=rs.getString(1);   
String stream_name=rs.getString(2); 

local.add(new Stream_info(course_id, stream_name));
}
}catch(Exception ex){
System.out.println(ex);
}
	finally
	{
		try{
			con.close();
		}catch(Exception ex)
		{
			System.out.println("Closing Exception-Stream_info");
		}
	
	}
return local;
}

public static int insertstream_info(Stream_info s)
{
try{
		
		String url ="jdbc:mysql://localhost:3306/onlineeductionalportal";
		Class.forName("com.mysql.jdbc.Driver");
		con =DriverManager.getConnection(url,"root","root");
		stmt= con.createStatement();
	}catch(Exception ex){
	System.out.println("Open Exception-Stream_info");	
	}
	String i1sqlj="insert into stream_info value(?,?)";
	int r=0;
	
	try{
		ps=con.prepareStatement(i1sqlj);
		ps.setString(1, s.getCourse_id());
		ps.setString(2, s.getStream_name());
		r=ps.executeUpdate();
		
	}catch(Exception ex)
	{
		System.out.println(ex);
	}
	finally
	{
		try{
			con.close();
		}catch(Exception ex)
		{
			System.out.println("Closing Exception-Stream_info");
		}
	
	}
	return r;
	
}

}
