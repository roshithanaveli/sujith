package com.controller;

import java.util.logging.*;
import java.io.File;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.jasper.tagplugins.jstl.core.Remove;

import com.controller.Admin_info_DAO;
import com.controller.Admin_info;

/**
 * Servlet implementation class AdminLogin
 */
@WebServlet("/AdminLogin")
public class AdminLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
    private static Logger log = Logger.getLogger(AdminLogin.class.getName());
    @Override
    public void init() throws ServletException 
{
          log.setLevel(Level.FINE);
          log.addHandler(new ConsoleHandler());
          try {
               File dir = new File("D:\\Logs");
               if(!dir.exists())
               {
                    dir.mkdir();
               }
               
               File file = new File(dir,"logger.log");
               Handler fileHandler = new FileHandler(file.getAbsolutePath(), 2000, 5);
               log.addHandler(fileHandler);
       } catch (SecurityException | IOException e1) {
           System.out.println("Exception on creating log file");
          e1.printStackTrace();
    }
}
    

       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminLogin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String user=request.getParameter("suji");
		String pass=request.getParameter("pass");
		
		Admin_info a=new Admin_info(Integer.parseInt(user), pass);
		HttpSession ses=request.getSession();
		ses.setAttribute("suji", a);
	//	ses.setAttribute("sug", user);
		
		if(Admin_info_DAO.check_id(a))
		{
			
			RequestDispatcher rd= request.getRequestDispatcher("home.jsp");
			rd.forward(request, response);
		
		}
		else
		{
			
		log.warning("user not found");
			request.setAttribute("errmsg", "<font color='red'>user not found</font>");
			RequestDispatcher rd= request.getRequestDispatcher("index.jsp");
			rd.forward(request, response);
		}
	}

}
