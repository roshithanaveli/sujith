package com.controller;



import java.sql.*;
import java.util.*;
import java.util.Date;
import java.text.*;
import java.util.concurrent.ExecutionException;
public class Payment_master_DAO 
{
private static Connection con;
private static Statement stmt;
private static ResultSet rs;
static PreparedStatement ps=null;


public static List<Payment_master> getpayment_master()
{
try{
		
		String url ="jdbc:mysql://localhost:3306/onlineeductionalportal";
		Class.forName("com.mysql.jdbc.Driver");
		con =DriverManager.getConnection(url,"root","root");
		stmt= con.createStatement();
	}
	catch(Exception ex)
	{
	System.out.println("Open Exception-Payment_master");	
	}
	List<Payment_master>local =new ArrayList<>();
	try{
		String query ="Select * from payment_master";
		rs=stmt.executeQuery(query);
		
		while(rs.next())
		{
			Integer student_id=rs.getInt(6);      
			Double balance=rs.getDouble(1);          
			Double total_fees=rs.getDouble(2);       
			Date last_payment_date=rs.getDate(3);  
			Double fine=rs.getDouble(4);             
			Double total_amount=rs.getDouble(5);     
		local.add(new Payment_master(student_id, balance, total_fees, last_payment_date, fine, total_amount));
		}
	}catch(Exception ex){
		System.out.println(ex);
	}
	
	finally
	{
		try{
			con.close();
		}catch(Exception ex)
		{
			System.out.println("Closing Exception-Payment_master");
		}
	

	}
	return local;
}



public static int insertpayment_master(Payment_master p)
{
try{
		
		String url ="jdbc:mysql://localhost:3306/onlineeductionalportal";
		Class.forName("com.mysql.jdbc.Driver");
		con =DriverManager.getConnection(url,"root","root");
		stmt= con.createStatement();
	}
	catch(Exception ex)
	{
	System.out.println("Open Exception-Payment_master");	
	}
	String i1sqlj="insert into payment_master value(?,?,?,?,?,?)";
	int r=0;
	SimpleDateFormat sdf =new SimpleDateFormat("yyyy-MM-dd");
	try{
		ps=con.prepareStatement(i1sqlj);
		
		Double bal = "NaN".equals(p.getBalance().toString()) ? Double.NaN : Double.parseDouble(p.getBalance().toString());
		Double tf = "NaN".equals(p.getTotal_fees().toString()) ? Double.NaN : Double.parseDouble(p.getTotal_fees().toString());
		Double fin = "NaN".equals(p.getFine().toString()) ? Double.NaN : Double.parseDouble(p.getFine().toString());
		Double ta = "NaN".equals(p.getTotal_amount().toString()) ? Double.NaN : Double.parseDouble(p.getTotal_amount().toString());
		
		
		ps.setInt(6, p.getStudent_id());
		ps.setDouble(1, bal);
		ps.setDouble(2, tf);
		ps.setDate(3, new java.sql.Date((p.getLast_payment_date()).getTime()));
		ps.setDouble(4, fin);
		ps.setDouble(5, ta);
		r=ps.executeUpdate();
		
	}catch(Exception ex)
	{
		System.out.println(ex);
	}
	
	finally
	{
		try{
			con.close();
		}catch(Exception ex)
		{
			System.out.println("Closing Exception-Payment_master");
		}
	

	}
	return r;
	
}


public static int updatepayment_master(Payment_master p)
{
try{
		
		String url ="jdbc:mysql://localhost:3306/onlineeductionalportal";
		Class.forName("com.mysql.jdbc.Driver");
		con =DriverManager.getConnection(url,"root","root");
		stmt= con.createStatement();
	}
	catch(Exception ex)
	{
	System.out.println("Open Exception-Payment_master");	
	}
	String i1sqlj="update payment_master set balance=?,total_fees=?,last_payment_date=?,fine=?,total_amount=? where student_id=?";
	int r=0;
	SimpleDateFormat sdf =new SimpleDateFormat("yyyy-MM-dd");
	try{
		ps=con.prepareStatement(i1sqlj);
	
		ps.setDouble(1, p.getBalance());
		ps.setDouble(2, p.getTotal_fees());
		ps.setDate(3, new java.sql.Date((p.getLast_payment_date()).getTime()));
		ps.setDouble(4, p.getFine());
		ps.setDouble(5, p.getTotal_amount());
		ps.setInt(6,p.getStudent_id());
		r=ps.executeUpdate();
		
	}catch(Exception ex)
	{
		System.out.println(ex);
	}
	
	finally
	{
		try{
			con.close();
		}catch(Exception ex)
		{
			System.out.println("Closing Exception-Payment_master");
		}
	

	}
	return r;
}




public static double finecal(Date a,String b) throws ParseException
{
	double abc=0.0;
	if(!b.equalsIgnoreCase("One-time"))
	{
	 SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
     
	 
	 Date d1=(a);
     Date d2=new Date();
     d2.setHours(0);
     d2.setMinutes(0);
     d2.setSeconds(0);
     
     
	  Calendar c=Calendar.getInstance();
      Calendar d=Calendar.getInstance();
      c.setTime(d1);
      d.setTime(d2);
	  System.out.println(c.getTime()+"-(1)-"+d.getTime()+"--"+b);

              if(b.equalsIgnoreCase("half yearly"))
              {
            	 c.add(Calendar.MONTH, 6); 
            	 
              }
              else if(b.equalsIgnoreCase("annual"))
              {
            	  c.add(Calendar.MONTH, 12);
              }
        	  System.out.println(c.getTime()+"-(2)-");

      if(c.getTime().before(d.getTime()))
      {
    	  System.out.println(c.getTime()+"-(3)-"+d.getTime());
    	   abc=(double) Math.abs(((c.getTime().getTime())-(d.getTime().getTime()))/(1000*60*60*24));		  		  
      }
      		
	System.out.println("##"+abc);
	}
	return abc;
}
}
