package com.controller;

import java.sql.*;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.*;
import java.text.*;
import java.util.concurrent.ExecutionException;
public class Discount_info_DAO {
private static Connection con;
private static Statement stmt;
private static ResultSet rs;

static PreparedStatement ps=null;


public static List<Discount_info> getsdiscount_info()
{
	try{
			
			String url ="jdbc:mysql://localhost:3306/onlineeducationportal";
			Class.forName("com.mysql.jdbc.Driver");
			con =DriverManager.getConnection(url,"root","root");
			stmt= con.createStatement();
		}
		catch(Exception ex)
		{
		System.out.println("Open Exception");	
		}
	List<Discount_info>local =new ArrayList<>();
	try{
		String query ="Select * from discount_info";
		rs=stmt.executeQuery(query);
		
		while(rs.next())
		{
			String course_id=rs.getString(1);  
			Double half_yearly=rs.getDouble(2);
			Double annual=rs.getDouble(3);     
			     
		local.add(new Discount_info(course_id, half_yearly, annual));
		}
	}catch(Exception ex){
		System.out.println(ex);
	}
	finally
	{
		try{
			con.close();
		}catch(Exception ex)
		{
			System.out.println("Closing Exception");
		}
	}
	return local;
}


public static int insertdiscount_info(String course_id, Double half_yearly, Double annual)
{
	try{
			
			String url ="jdbc:mysql://localhost:3306/onlineeductionalportal";
			Class.forName("com.mysql.jdbc.Driver");
			con =DriverManager.getConnection(url,"root","root");
			stmt= con.createStatement();
		}
		catch(Exception ex)
		{
		System.out.println("Open Exception");	
		}
	String i1sqlj="insert into discount_info value(?,?,?)";
	int r=0;
	
	try{
		ps=con.prepareStatement(i1sqlj);
		ps.setString(1, course_id);
		ps.setDouble(2, half_yearly);
		ps.setDouble(3, annual);
		r=ps.executeUpdate();
		
	}catch(Exception ex)
	{
		System.out.println(ex);
	}
	finally
	{
		try{
			con.close();
		}catch(Exception ex)
		{
			System.out.println("Closing Exception");
		}
	}
	return r;
	
}

}