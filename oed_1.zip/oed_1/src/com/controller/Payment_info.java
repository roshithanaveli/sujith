package com.controller;
import java.util.*;

public class Payment_info {
	private Integer payment_id;
	private Integer studennt_id;
	private Integer payment_for;
	private Date payment_date;
	public Payment_info(Integer payment_id, Integer studennt_id,
			Integer payment_for, Date payment_date) {
		super();
		this.payment_id = payment_id;
		this.studennt_id = studennt_id;
		this.payment_for = payment_for;
		this.payment_date = payment_date;
	}
	public Payment_info() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Integer getPayment_id() {
		return payment_id;
	}
	public void setPayment_id(Integer payment_id) {
		this.payment_id = payment_id;
	}
	public Integer getStudennt_id() {
		return studennt_id;
	}
	public void setStudennt_id(Integer studennt_id) {
		this.studennt_id = studennt_id;
	}
	public Integer getPayment_for() {
		return payment_for;
	}
	public void setPayment_for(Integer payment_for) {
		this.payment_for = payment_for;
	}
	public Date getPayment_date() {
		return payment_date;
	}
	public void setPayment_date(Date payment_date) {
		this.payment_date = payment_date;
	}
	


}