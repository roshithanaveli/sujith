package com.controller;
public class Stream_info 
{
	private String course_id;
	private String stream_name;
	public Stream_info(String course_id, String stream_name) {
		super();
		this.course_id = course_id;
		this.stream_name = stream_name;
	}
	public Stream_info() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getCourse_id() {
		return course_id;
	}
	public void setCourse_id(String course_id) {
		this.course_id = course_id;
	}
	public String getStream_name() {
		return stream_name;
	}
	public void setStream_name(String stream_name) {
		this.stream_name = stream_name;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((course_id == null) ? 0 : course_id.hashCode());
		result = prime * result
				+ ((stream_name == null) ? 0 : stream_name.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Stream_info other = (Stream_info) obj;
		if (course_id == null) {
			if (other.course_id != null)
				return false;
		} else if (!course_id.equals(other.course_id))
			return false;
		if (stream_name == null) {
			if (other.stream_name != null)
				return false;
		} else if (!stream_name.equals(other.stream_name))
			return false;
		return true;
	}
	
	   
}

