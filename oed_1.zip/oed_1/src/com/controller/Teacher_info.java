package com.controller;

public class Teacher_info {
private String teacher_id;
private String teacher_name;
private String high_qual;
private String teacher_email;
private String teacher_contact;
private String teacher_address;
private Integer teacher_experience;
private Integer rating;
public Teacher_info(String teacher_id, String teacher_name, String high_qual,
		String teacher_email, String teacher_contact, String teacher_address,
		Integer teacher_experience, Integer rating) {
	super();
	this.teacher_id = teacher_id;
	this.teacher_name = teacher_name;
	this.high_qual = high_qual;
	this.teacher_email = teacher_email;
	this.teacher_contact = teacher_contact;
	this.teacher_address = teacher_address;
	this.teacher_experience = teacher_experience;
	this.rating = rating;
}
public Teacher_info() {
	super();
	// TODO Auto-generated constructor stub
}
public String getTeacher_id() {
	return teacher_id;
}
public void setTeacher_id(String teacher_id) {
	this.teacher_id = teacher_id;
}
public String getTeacher_name() {
	return teacher_name;
}
public void setTeacher_name(String teacher_name) {
	this.teacher_name = teacher_name;
}
public String getHigh_qual() {
	return high_qual;
}
public void setHigh_qual(String high_qual) {
	this.high_qual = high_qual;
}
public String getTeacher_email() {
	return teacher_email;
}
public void setTeacher_email(String teacher_email) {
	this.teacher_email = teacher_email;
}
public String getTeacher_contact() {
	return teacher_contact;
}
public void setTeacher_contact(String teacher_contact) {
	this.teacher_contact = teacher_contact;
}
public String getTeacher_address() {
	return teacher_address;
}
public void setTeacher_address(String teacher_address) {
	this.teacher_address = teacher_address;
}
public Integer getTeacher_experience() {
	return teacher_experience;
}
public void setTeacher_experience(Integer teacher_experience) {
	this.teacher_experience = teacher_experience;
}
public Integer getRating() {
	return rating;
}
public void setRating(Integer rating) {
	this.rating = rating;
}


}
