package com.controller;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


public class Teacher_infoDAO {
	private static Connection con;
	private static Statement stmt;
	private static ResultSet rs;
	static PreparedStatement ps=null;
	

	
	
	public static List<Teacher_info> get_teacher_info()
	{
		List<Teacher_info>local =new ArrayList<>();
		
try{
			
			String url ="jdbc:mysql://localhost:3306/onlineeductionalportal";
			Class.forName("com.mysql.jdbc.Driver");
			con =DriverManager.getConnection(url,"root","root");
			stmt= con.createStatement();
		}catch(Exception ex){
		System.out.println("Open Exception-teacher_info");	
		}


		try{
			String query ="Select * from teacher_info";
			rs=stmt.executeQuery(query);
			
			while(rs.next())
			{
				
				String teacher_id=rs.getString(1);         
				String teacher_name=rs.getString(2);       
				String high_qual=rs.getString(3);          
				String teacher_email=rs.getString(4);      
				String teacher_contact=rs.getString(5);    
				String teacher_address=rs.getString(6);    
				Integer teacher_experience=rs.getInt(7); 
				Integer rating=rs.getInt(8);            
				
			local.add(new Teacher_info(teacher_id, teacher_name, high_qual, teacher_email, teacher_contact, teacher_address, teacher_experience, rating));
			}
		}catch(Exception ex){
			System.out.println(ex);
		}finally
		{
			try{
				con.close();
			}catch(Exception ex)
			{
				System.out.println("Closing Exception-get_teacher_info");
			}
		
		}
		return local;
	}
	public static int insert_teacher_info(String teacher_id, String teacher_name, String high_qual,
			String teacher_email, String teacher_contact, String teacher_address,
			Integer teacher_experience, Integer rating)
	{
		int r=0;
		 String i1sqlj="insert into teacher_info value(?,?,?,?,?,?,?,?)";
		SimpleDateFormat sdf =new SimpleDateFormat("yyyy-MM-dd");
		
try{
			
			String url ="jdbc:mysql://localhost:3306/onlineeductionalportal";
			Class.forName("com.mysql.jdbc.Driver");
			con =DriverManager.getConnection(url,"root","root");
			stmt= con.createStatement();
		}catch(Exception ex){
		System.out.println("Open Exception-teacher_info");	
		}
		try{
			ps=con.prepareStatement(i1sqlj);
			
			ps.setString(1, teacher_id);
			ps.setString(2, teacher_name);
			ps.setString(3, high_qual);
			ps.setString(4, teacher_email);
			ps.setString(5, teacher_contact);
			ps.setString(6, teacher_address);
			ps.setInt(7, teacher_experience);
			ps.setInt(8, rating);
			
			r=ps.executeUpdate();
			
		}catch(Exception ex)
		{
			System.out.println(ex);
		}finally
		{
			try{
				con.close();
			}catch(Exception ex)
			{
				System.out.println("Closing Exception-insert_teacher_info");
			}
		
		}
		return r;
		
	}
	
	

}
