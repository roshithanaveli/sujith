package com.controller;

import java.sql.*;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.*;
import java.text.*;
import java.util.concurrent.ExecutionException;

import com.controller.Admin_info;


public class Admin_info_DAO {
private static Connection con;
private static Statement stmt;
private static ResultSet rs;

//static String i1sqlj="insert into customer value(?,?,?,?,?)";

static PreparedStatement ps=null;

static{
	try{
		
		String url ="jdbc:mysql://localhost:3306/onlineeductionalportal";
		Class.forName("com.mysql.jdbc.Driver");
		con =DriverManager.getConnection(url,"root","root");
		stmt= con.createStatement();
	}catch(Exception ex){
	System.out.println("Open Exception-at admin_info_DAO");	
	}
}

public static List<Admin_info> getsadmin_info()
{
	List<Admin_info>local =new ArrayList<>();
	try{
		String query ="Select * from admin_info";
		rs=stmt.executeQuery(query);
		
		while(rs.next())
		{
			 Integer user_id=rs.getInt(1);   
			 String user_password=rs.getString(2); 
			     
		local.add(new Admin_info(user_id, user_password));
		}
	}catch(Exception ex){
		System.out.println(ex);
	}
	return local;
}

public static boolean check_id(Admin_info a)
{
 boolean ret=false;
 List<Admin_info> alist = Admin_info_DAO.getsadmin_info();

// System.out.println(a.getUser_id());
// System.out.println(a.getUser_password());
// System.out.println("========");

 for(Admin_info x: alist)
 {
//	
//     System.out.println(x.getUser_id());
//	 System.out.println(x.getUser_password());

	 
	 if( x.getUser_id()==((int)a.getUser_id()) && x.getUser_password().equals(a.getUser_password()))
	 { 
		 System.out.println(1);
		 ret= true;
	     break;
	 }
 }
 
 return ret;
}

public static int insertadmin_info(Integer user_id, String user_password)
{
	String i1sqlj="insert into admin_info value(?,?)";
	int r=0;
	
	try{
		ps=con.prepareStatement(i1sqlj);
		ps.setInt(1, user_id);
		ps.setString(2, user_password);
		r=ps.executeUpdate();
		
	}catch(Exception ex)
	{
		System.out.println(ex);
	}
	return r;
	
}
public void finalize_admin_info()
{

		try{
			con.close();
		}catch(Exception ex)
		{
			System.out.println("Closing Exception");
		}
	

}
}



