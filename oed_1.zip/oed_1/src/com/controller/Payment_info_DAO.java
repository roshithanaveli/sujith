package com.controller;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Date;
import java.util.concurrent.ExecutionException;
public class Payment_info_DAO {

	private static Connection con;
	private static Statement stmt;
	private static ResultSet rs;
	static PreparedStatement ps=null;

	
	public static List<Payment_info> getPayment_info()
	{
		try{
				
				String url ="jdbc:mysql://localhost:3306/onlineeductionalportal";
				Class.forName("com.mysql.jdbc.Driver");
				con =DriverManager.getConnection(url,"root","root");
				stmt= con.createStatement();
			}
		catch(Exception ex)
			{
			System.out.println("Open Exception-Payment_info");	
			}
		List<Payment_info>local =new ArrayList<>();
		try{
			String query ="Select * from payment_info";
			rs=stmt.executeQuery(query);
			
			while(rs.next())
			{
				Integer payment_id=rs.getInt(1); 
				Integer studennt_id=rs.getInt(2);
				Integer payment_for=rs.getInt(3);
				Date payment_date=rs.getDate(4);  
				     
			local.add(new Payment_info(payment_id, studennt_id, payment_for, payment_date));
			}
		}catch(Exception ex){
			System.out.println(ex);
		}
		finally
		{
			try{
				con.close();
			}catch(Exception ex)
			{
				System.out.println("Closing Exception-Payment_info");
			}
		}
		return local;
	}
	
	
	public static int insertpayment_info(Payment_info p)
	{
		try{
			
			String url ="jdbc:mysql://localhost:3306/onlineeductionalportal";
			Class.forName("com.mysql.jdbc.Driver");
			con =DriverManager.getConnection(url,"root","root");
			stmt= con.createStatement();
		}
		catch(Exception ex)
		{
		System.out.println("Open Exception-Payment_info");	
		}
		String query ="Insert into payment_info values(?,?,?,?)";
		int r=0;
		
		try{
			ps=con.prepareStatement(query);
			ps.setInt(1, p.getPayment_id());
			ps.setInt(2, p.getStudennt_id());
			ps.setInt(3, p.getPayment_for());

			ps.setDate(4, new java.sql.Date(p.getPayment_date().getTime()));
			
			r=ps.executeUpdate();
			
		}catch(Exception ex)
		{
			System.out.println(ex);
		}
		finally
		{
			try{
				con.close();
			}catch(Exception ex)
			{
				System.out.println("Closing Exception-Payment_info");
			}
		}
		return r;
		
	}
	public static int calculatesem(Date d)
	{
		int sem=0;
		Date d2=new Date();
		d2.setHours(0);
		d2.setMinutes(0);
		d2.setSeconds(0);
		
		
		while(d.before(d2))
		{
			sem++;
			Calendar a=Calendar.getInstance();
			a.setTime(d);
			a.add(Calendar.MONTH, 6);
			d=a.getTime();		
		}
		
		
		return sem;
	}
	
	
}




