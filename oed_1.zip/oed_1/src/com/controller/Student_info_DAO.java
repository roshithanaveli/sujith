package com.controller;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Date;

import com.password.Decryption;

	public class Student_info_DAO {
	private static Connection con;
	private static Statement stmt;
	private static ResultSet rs;
	static PreparedStatement ps=null;
	
	
	public static List<Student_info> getStudent_info()
	{
		try{
			
			String url ="jdbc:mysql://localhost:3306/onlineeductionalportal";
			Class.forName("com.mysql.jdbc.Driver");
			con =DriverManager.getConnection(url,"root","root");
			stmt= con.createStatement();
		}
		catch(Exception ex)
		{
		System.out.println("Open Exception-Stundet_info");	
		}
		List<Student_info>local =new ArrayList<>();
		try{
			String query ="Select * from student_info";
			rs=stmt.executeQuery(query);
			
			while(rs.next())
			{
				Integer student_id=rs.getInt(1);    	
			
				String student_name=rs.getString(2);       				

				String student_password=rs.getString(3);   				

				String student_email=rs.getString(4);      			

				String student_contact=rs.getString(5);    				

				String student_address=rs.getString(6);         	

				String course_id=rs.getString(10);          	

				Date registration_date=rs.getDate(7);    	

				String guardian_name=rs.getString(8);      

				String mode_of_payment=rs.getString(9);    		
			
  Student_info s=new Student_info(student_id, student_name, Decryption.decry(student_password), student_email, student_contact, student_address, course_id, registration_date, guardian_name, mode_of_payment);
				
				
			local.add(s);
			}
		}
		catch(Exception ex)
		{
			System.out.println(ex);
		}
		finally
		{
			try{
				con.close();
			}catch(Exception ex)
			{
				System.out.println("Closing Exception-Student_info");
			}
		}
		
		for(Student_info x:local)
		{
			System.out.println(x.getStudent_id()+"@@");
		}
		return local;
	 }
	
	
	
	
	public static String course_id(String course_name)
	{
		try{
			
			String url ="jdbc:mysql://localhost:3306/onlineeductionalportal";
			Class.forName("com.mysql.jdbc.Driver");
			con =DriverManager.getConnection(url,"root","root");
			stmt= con.createStatement();
		}
		catch(Exception ex)
		{
		System.out.println("Open Exception-Stundet_info");	
		}
		String ret="";
		try{
			String q=String.format("select course_id from course_info where course_name='%s'",course_name);
			rs=stmt.executeQuery(q);
			while(rs.next())
			{
			ret= rs.getString(1);
			}
		}catch(Exception ex)
		{
			System.out.println(ex);
		}
		finally
		{
			try{
				con.close();
			}catch(Exception ex)
			{
				System.out.println("Closing Exception-Student_info");
			}
		}
		return ret;
	}
	
	
	
	public static int course_period(String course_name)
	{
		try{
			
			String url ="jdbc:mysql://localhost:3306/onlineeductionalportal";
			Class.forName("com.mysql.jdbc.Driver");
			con =DriverManager.getConnection(url,"root","root");
			stmt= con.createStatement();
		}
		catch(Exception ex)
		{
		System.out.println("Open Exception-Stundet_info");	
		}
		int ret=0;
		try{
			String q=String.format("select period from course_info where course_id='%s'",course_name);
			rs=stmt.executeQuery(q);
			while(rs.next())
			{
			ret= rs.getInt(1);
			}
		}catch(Exception ex)
		{
			System.out.println(ex);
		}
		finally
		{
			try{
				con.close();
			}catch(Exception ex)
			{
				System.out.println("Closing Exception-Student_info");
			}
		}
		return ret;
	}
	
	public static double course_fee(String course_name)
	{
		System.out.println("cours_fee(1.1)");
		try{
			
			String url ="jdbc:mysql://localhost:3306/onlineeductionalportal";
			Class.forName("com.mysql.jdbc.Driver");
			con =DriverManager.getConnection(url,"root","root");
			stmt= con.createStatement();
		}
		catch(Exception ex)
		{
		System.out.println("Open Exception-Stundet_info");	
		}
		double ret=0;
		try{
			String q=String.format("select course_fees from course_info where course_id='%s'",course_name);
			rs=stmt.executeQuery(q);
			if(rs.next())
			{
				

			ret= rs.getDouble(1)/1.0;
			}
		}catch(Exception ex)
		{
			System.out.println(ex);
		}
		finally
		{
			try{
				con.close();
			}catch(Exception ex)
			{
				System.out.println("Closing Exception-Student_info");
			}
		}
		return ret;
	}
	
	public static boolean insert_student_info(Integer student_id, String student_name,
			String student_password, String student_email,
			String student_contact, String student_address, String course_name,
			Date registration_date, String guardian_name, String mode_of_payment)
	{
		try{
			
			String url ="jdbc:mysql://localhost:3306/onlineeductionalportal";
			Class.forName("com.mysql.jdbc.Driver");
			con =DriverManager.getConnection(url,"root","root");
			stmt= con.createStatement();
		}
		catch(Exception ex)
		{
		System.out.println("Open Exception-Stundet_info");	
		}
		boolean r=true;
		 String i1sqlj="insert into student_info value(?,?,?,?,?,?,?,?,?,?)";
	
		try{
			
			ps=con.prepareStatement(i1sqlj);
			
			ps.setInt(1, student_id);
			ps.setString(2, student_name);
			ps.setString(3, student_password);
			ps.setString(4, student_email);
			ps.setString(5, student_contact);
			ps.setString(6, student_address);
			ps.setString(10, (course_name));
			ps.setDate(7, new java.sql.Date(registration_date.getTime()));
			ps.setString(8, guardian_name);
			ps.setString(9, mode_of_payment);
			
	
			r=ps.execute();
			
		}catch(Exception ex)
		{
			System.out.println(ex);
		}
		finally
		{
			try{
				con.close();
			}catch(Exception ex)
			{
				System.out.println("Closing Exception-Student_info");
			}
		}
		         
		double total_fees=course_fee(course_name)-(course_fee(course_name)*(get_discount((course_name), mode_of_payment)/100));      
		double balance= total_fees;
		Date last_payment_date=registration_date; 
		double fine=0.0;     
		
		double total_amount=total_fees/(no_sem(mode_of_payment,course_period(course_name)));    
	
		Payment_master pm=new Payment_master(student_id, balance, total_fees, last_payment_date, fine, total_amount);
	
		
		int a=Payment_master_DAO.insertpayment_master(pm);
		if(a==1)
			System.out.println("pay_mas(1)");
		else
			System.out.println("pay_mas(0)");
	
		return r;
	}
	
	
	

	
	
	public static double no_sem(String mode_of_payment,int period)
	{
		switch(mode_of_payment.toLowerCase())
		{
		case "half yearly":  return (period*2.0);
		case "annual": return (period*1.0);
		default: return(1.0);                  	
		}
	}
	
    

	
	
	public static double get_discount(String course_id,String mode_of_payment)
	{
		double ret=0;
		if(mode_of_payment.equalsIgnoreCase("Half yearly"))
		{
			ret=0.0;
		}
		else
		{
		try{
			
			String url ="jdbc:mysql://localhost:3306/onlineeductionalportal";
			Class.forName("com.mysql.jdbc.Driver");
			con =DriverManager.getConnection(url,"root","root");
			stmt= con.createStatement();
		}
		catch(Exception ex)
		{
		System.out.println("Open Exception-Stundet_info");	
		}
		String mp="";
		if(mode_of_payment.toLowerCase().equals("one-time"))
			mp="one_time";
		else
			mp="annual";
		try{
			String q=String.format("select %s from discount_info where course_id='%s'",mp,course_id);
			rs=stmt.executeQuery(q);
			while(rs.next())
			{
			ret= rs.getInt(1)/1.0;
			}	
		}catch(Exception ex)
		{
			System.out.println(ex);
		}
		finally
		{
			try{
				con.close();
			}catch(Exception ex)
			{
				System.out.println("Closing Exception-Student_info");
			}
		}
		}
		return ret;
	}
	

}
