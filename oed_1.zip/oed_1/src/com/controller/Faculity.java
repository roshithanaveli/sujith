package com.controller;

import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.*;
import java.util.logging.ConsoleHandler;
import java.util.logging.FileHandler;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.sun.xml.internal.ws.policy.privateutil.PolicyUtils.Collections;

import sun.org.mozilla.javascript.internal.regexp.SubString;



/**
 * Servlet implementation class Faculity
 */
@WebServlet("/Faculity")
public class Faculity extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	 private static Logger log = Logger.getLogger(Faculity.class.getName());
	    @Override
	    public void init() throws ServletException 
	{
	          log.setLevel(Level.FINE);
	          log.addHandler(new ConsoleHandler());
	          try {
	               File dir = new File("D:\\Logs");
	               if(!dir.exists())
	               {
	                    dir.mkdir();
	               }
	               
	               File file = new File(dir,"logger.faculity");
	               Handler fileHandler = new FileHandler(file.getAbsolutePath(), 2000, 5);
	               log.addHandler(fileHandler);
	       } catch (SecurityException | IOException e1) {
	           System.out.println("Exception on creating log file");
	          e1.printStackTrace();
	    }
	}
	    
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Faculity() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
		
		List<Teacher_info> tlist=Teacher_infoDAO.get_teacher_info();
		List<Integer> idlist=new ArrayList<>();
		

		DecimalFormat df=new DecimalFormat("0000");
		int n=1;
		if(tlist.isEmpty());
		else
		{
			for(Teacher_info x:tlist)
			{
				idlist.add(Integer.parseInt(x.getTeacher_id().substring(3)));
			}
			java.util.Collections.sort(idlist);
			n=idlist.get(idlist.size()-1)+1;
		}
		String teacher_id="FAC"+df.format(n);         
		String teacher_name=request.getParameter("name");       
		String high_qual=request.getParameter("hq"); ;          
		String teacher_email=request.getParameter("email"); ;      
		String teacher_contact=request.getParameter("contact"); ;    
		String teacher_address=request.getParameter("address"); ;    
		Integer teacher_experience=Integer.parseInt(request.getParameter("exp")) ;
		Integer rating=5;   
		
		int i=Teacher_infoDAO.insert_teacher_info(teacher_id, teacher_name, high_qual, teacher_email, teacher_contact, teacher_address, teacher_experience, rating);
		 String msg="";
		
		if(i==1)
		 {
			 System.out.println("success");
				msg="<h1><font color='green'> Faculty details has been successfully registered</font></h1>";
		 }
			 else
			 {	 System.out.println("fail");
				msg="<h2><font color='red'> Faculty details not registered </font></h2>";
			 }
		HttpSession ses=request.getSession();
		log.warning(msg);
		ses.setAttribute("msg1",msg);
		RequestDispatcher rd= request.getRequestDispatcher("end1.jsp");
		rd.forward(request, response);

	}

}
