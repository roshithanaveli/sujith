package com.controller;

import java.io.File;
import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.ConsoleHandler;
import java.util.logging.FileHandler;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.password.Encryption;

/**
 * Servlet implementation class Student
 */
@WebServlet("/Student")
public class Student extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private static Logger log = Logger.getLogger(Student.class.getName());
    @Override
    public void init() throws ServletException 
{
          log.setLevel(Level.FINE);
          log.addHandler(new ConsoleHandler());
          try {
               File dir = new File("D:\\Logs");
               if(!dir.exists())
               {
                    dir.mkdir();
               }
               
               File file = new File(dir,"logger.student");
               Handler fileHandler = new FileHandler(file.getAbsolutePath(), 2000, 5);
               log.addHandler(fileHandler);
       } catch (SecurityException | IOException e1) {
           System.out.println("Exception on creating log file");
          e1.printStackTrace();
    }
}
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Student() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		Date registration_date = null;

		List<Student_info> slist=Student_info_DAO.getStudent_info();
		List<Integer> idlist=new ArrayList<>();
		System.out.println(1.1);

		//DecimalFormat df=new DecimalFormat("0000");
		int n=1000;
		System.out.println(slist.size());

		if(slist.size()>0 )
		{
			System.out.println(2);

			for(Student_info x:slist)
			{
				idlist.add(x.getStudent_id());
			}
			System.out.println(idlist.size());
			java.util.Collections.sort(idlist);
			n=idlist.get(idlist.size()-1)+1;
		}
		
		System.out.println("=="+n);

		int student_id=n;        
	       
		String student_name=request.getParameter("student_name");         
		String student_password=request.getParameter("student_password");     
		String student_email=request.getParameter("student_email");        
		String student_contact=request.getParameter("student_contact");      
		String student_address=request.getParameter("student_address");      
		String course_id=(request.getParameter("course_name"));            
		try {
			 registration_date=sdf.parse(request.getParameter("date"));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}      
		String guardian_name=request.getParameter("guardian");        
		String mode_of_payment=request.getParameter("mode_of_pay"); 
		System.out.println(Student_info_DAO.course_id(course_id));
	
		boolean i=true;
		try {
			i = Student_info_DAO.insert_student_info(student_id, student_name, Encryption.encryp(student_password), student_email, student_contact, student_address, Student_info_DAO.course_id(course_id), registration_date, guardian_name, mode_of_payment);
		} catch (InvalidKeyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvalidAlgorithmParameterException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalBlockSizeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (BadPaddingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(i+"===");
String msg="";
		if(!i)
		{
			System.out.println("sucessfull");
			msg="<h1><font color='green'> Student details has been successfully inserted </font></h1>";

		}
		else
		{
			System.out.println("not sucessfull");
			msg="<h1><font color='red'> Student details not inserted </font></h1>";

		
		}
		HttpSession ses=request.getSession();

		log.warning(msg);
		ses.setAttribute("msg1",msg);
		RequestDispatcher rd= request.getRequestDispatcher("end1.jsp");
		rd.forward(request, response);
		
	}

}
