package com.controller;
import java.util.logging.*;
import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Course
 */
@WebServlet("/Course")
public class Course extends HttpServlet {
	private static final long serialVersionUID = 1L;
       private static int i=0;
       private static int j=0;
       
       private static Logger log = Logger.getLogger(Course.class.getName());
       @Override
       public void init() throws ServletException 
  {
             log.setLevel(Level.FINE);
             log.addHandler(new ConsoleHandler());
             try {
                  File dir = new File("D:\\Logs");
                  if(!dir.exists())
                  {
                       dir.mkdir();
                  }
                  
                  File file = new File(dir,"logger.course");
                  Handler fileHandler = new FileHandler(file.getAbsolutePath(), 2000, 5);
                  log.addHandler(fileHandler);
          } catch (SecurityException | IOException e1) {
              System.out.println("Exception on creating log file");
             e1.printStackTrace();
       }
  }
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Course() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    
    static String course_name=null;
    static String course_id=null;
	static HttpSession ses1=null;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	    ses1=request.getSession();
		 course_id=request.getParameter("id"); 
		 course_name=request.getParameter("course_name"); 
		String s1="";
		 List<Course_info>clist=Course_info_DA.getcourse_info();
	 String s="<tr> <td align='center'>Course Duration:</td> <td><input type='text' name='duration' pattern='[0-9]' title='Only Numbers' required></td></tr><tr> <td>&nbsp;</td> </tr><tr><td align='center'>Course Fees:</td><td><input type='text' name='fees'></td></tr><tr> <td>&nbsp;</td> </tr><tr> <td align='center'>Discount(Annual-pay):</td> <td><input type='text' name='da'></td></tr><tr> <td>&nbsp;</td> </tr><tr>  <td align='center'>Discount(Onetime-pay):</td> <td><input type='text' name='do'></td></tr><tr> <td>&nbsp;</td> </tr>";
		 for(Course_info x: clist)
		 {
			 if(course_name.equals(x.getCourse_name()))
			 {
				 j=1;
				 System.out.println("@@@"+j);
				 s="<font color='white'>course already exist</font>";
				 break;
			 }
		 }
		 
		
		 ses1.setAttribute("exist", s);
     	
		 course_name=request.getParameter("course_name");
     	List<String>sl=null;
     	if(course_name.equals("B.Tech") || course_name.equals("M.Tech"))
     	{
     		s1="<option>--Select--</option><option>IT</option><option>CSC</option><option>ECE</option><option>Mech</option>";
     	}else if(course_name.equals("MBA"))
     	{
     		s1="<option>--Select--</option><option>HR</option><option>OPERATION</option><option>FINANCE</option>";
     	}
     	else
     	{
     		s1="<option>No Stream</option>";
     	}
     	
     	ses1.setAttribute("stream", s1);
  i=1;  
    	ses1.setAttribute("c_id",course_id);
     	ses1.setAttribute("c_name", course_name);
		RequestDispatcher rd= request.getRequestDispatcher("course2.jsp");
		rd.forward(request, response);
		
	 System.out.println(course_id);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
	
		HttpSession ses=request.getSession();
		String stream_name = null;
		Course_info c = null;
		int c1=0;
		int s1=0;
		String msg="";
		System.out.println("+__+_+"+j);
		try{


	
		 stream_name=request.getParameter("stream");
		
		   
			
			System.out.println(stream_name);
			System.out.println("+++"+j);
			if(j==0)
			{
				Integer period=Integer.parseInt(request.getParameter("duration"));     
				Double course_fees=Double.parseDouble(request.getParameter("fees")); 
				double  annual_dis=Double.parseDouble(request.getParameter("da"));
				double ot_dis=Double.parseDouble(request.getParameter("do"));
				c=new Course_info(course_id, course_name, period, course_fees);
				Discount_info_DAO.insertdiscount_info(course_id, ot_dis, annual_dis);
			c1=Course_info_DA.insertcourse_info(c);
			}
			Stream_info s=new Stream_info(course_id, stream_name);
			List<Stream_info> slist =Stream_info_DAO.getstream_info();
	    	int z=0;
			for(Stream_info x: slist)
			{
				if(s.equals(x))
				{
					z=1;
					break;
				}
			}
			if(z==0){
			s1=Stream_info_DAO.insertstream_info(s);
			}
		
			
			if(c1==1)
				System.out.println("course-1");
			else
				System.out.println("course-0");
			if(s1==1)
				System.out.println("stream-1");
			else
				System.out.println("stream-0");
			
			if(s1==1 || c1==1)
			{
			
			msg="<h1><font color='green'> Course details has been successfully inserted </font></h1>";
			}else
			{
				msg="<h1><font color='red'> Course details not inserted </font></h1>";

			}
			
		}catch(Exception ex)
		{
		msg="<h1><font color='red'> Course details not inserted </font></h1>";

		}finally
		{
		try
		{if(i==1)
		{
		ses1.removeAttribute("c_id");
		ses1.removeAttribute("c_name");
		ses1.removeAttribute("exist");
		}
		}catch(Exception ex)
		{
			msg="<h1><font color='red'> Course details not inserted </font></h1>";
		}
		log.warning("Course details not inserted");
		ses.setAttribute("msg1",msg);
		RequestDispatcher rd= request.getRequestDispatcher("end1.jsp");
		rd.forward(request, response);

		}
		
	}

}
