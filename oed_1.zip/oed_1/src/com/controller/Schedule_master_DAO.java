package com.controller;


import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Date;
import java.util.concurrent.ExecutionException;
	public class Schedule_master_DAO {

		private static Connection con;
		private static Statement stmt;
		private static ResultSet rs;
		static PreparedStatement ps=null;

		static String i1sql="insert into Schedule_master value(?,?,?,?)";
		
		
		public static String course_id(String course_name)
		{
			try{
				
				String url ="jdbc:mysql://localhost:3306/onlineeductionalportal";
				Class.forName("com.mysql.jdbc.Driver");
				con =DriverManager.getConnection(url,"root","root");
				stmt= con.createStatement();
			}catch(Exception ex){
			System.out.println("Open Exception-Schedule_master");	
			}
			String ret="";
			try{
				String q=String.format("select course_id from course_info where course_name='%s'",course_name);
				rs=stmt.executeQuery(q);
				while(rs.next())
				{
				ret= rs.getString(1);
				}			
			}catch(Exception ex)
			{
				System.out.println(ex);
			}
			finally
			{
				try{
					con.close();
				}catch(Exception ex)
				{
					System.out.println("Closing Exception-Schedule_master");
				}
			}
			return ret;
		}
		
		
		
		
		public static List<Schedule_master> getschedule_master()
		{
		try{
				
				String url ="jdbc:mysql://localhost:3306/onlineeductionalportal";
				Class.forName("com.mysql.jdbc.Driver");
				con =DriverManager.getConnection(url,"root","root");
				stmt= con.createStatement();
			}
			catch(Exception ex)
			{
			System.out.println("Open Exception-Schedule_master");	
			}
			List<Schedule_master>local =new ArrayList<>();
			try{
				String query ="Select * from schedule_master";
				rs=stmt.executeQuery(query);
				
				while(rs.next())
				{
					String course_id=rs.getString(1); 
					Integer semester=rs.getInt(2); 
					Date start_date=rs.getDate(3);  
					Date end_date=rs.getDate(4);        
				local.add(new Schedule_master(course_id, semester, start_date, end_date));
				}
			}catch(Exception ex){
				System.out.println(ex);
			}
			
			finally
			{
				try{
					con.close();
				}catch(Exception ex)
				{
					System.out.println("Closing Exception-Schedule_master");
				}
			

			}
			return local;
		}
		
		
		
		
		
		
		public static int insertschedule_master(Schedule_master s)
		{
			try{
				
				String url ="jdbc:mysql://localhost:3306/onlineeductionalportal";
				Class.forName("com.mysql.jdbc.Driver");
				con =DriverManager.getConnection(url,"root","root");
				stmt= con.createStatement();
			}
			catch(Exception ex)
			{
			System.out.println("Open Exception-Schedule_master");	
			}
			String i1sql="insert into schedule_master value(?,?,?,?)";
			int r=0;
			//SimpleDateFormat sdf =new SimpleDateFormat("yyyy-MM-dd");
			try{
				ps=con.prepareStatement(i1sql);
				ps.setString(1, course_id(s.getCourse_id()));
				ps.setInt(2, s.getSemester());

				ps.setDate(3, new java.sql.Date(s.getStart_date().getTime()));
				ps.setDate(4, new java.sql.Date(s.getEnd_date().getTime()));

				
				r=ps.executeUpdate();
				
			}catch(Exception ex)
			{
				System.out.println(ex);
			}
			finally
			{
				try{
					con.close();
				}catch(Exception ex)
				{
					System.out.println("Closing Exception-Schedule_master");
				}
			}
			return r;
			
		}

		
	}









