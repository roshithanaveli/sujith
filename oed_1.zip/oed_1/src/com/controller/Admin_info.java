package com.controller;

public class Admin_info
{
	private Integer user_id;
	private String user_password;
	public Admin_info(Integer user_id, String user_password) {
		super();
		this.user_id = user_id;
		this.user_password = user_password;
	}
	public Admin_info() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Integer getUser_id() {
		return user_id;
	}
	public void setUser_id(Integer user_id) {
		this.user_id = user_id;
	}
	public String getUser_password() {
		return user_password;
	}
	public void setUser_password(String user_password) {
		this.user_password = user_password;
	}
	@Override
	public String toString() {
		return "Admin_info [user_id=" + user_id + ", user_password="
				+ user_password + "]";
	}
	
	
}



