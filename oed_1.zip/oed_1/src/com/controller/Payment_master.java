package com.controller;
import java.util.*;
public class Payment_master 
{
	private Integer student_id;
	private Double balance;
	private Double total_fees;
	private Date last_payment_date;
	private Double fine;
	private Double total_amount;
	public Payment_master(Integer student_id, Double balance,
			Double total_fees, Date last_payment_date, Double fine,
			Double total_amount) {
		super();
		this.student_id = student_id;
		this.balance = balance;
		this.total_fees = total_fees;
		this.last_payment_date = last_payment_date;
		this.fine = fine;
		this.total_amount = total_amount;
	}
	public Payment_master() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Integer getStudent_id() {
		return student_id;
	}
	public void setStudent_id(Integer student_id) {
		this.student_id = student_id;
	}
	public Double getBalance() {
		return balance;
	}
	public void setBalance(Double balance) {
		this.balance = balance;
	}
	public Double getTotal_fees() {
		return total_fees;
	}
	public void setTotal_fees(Double total_fees) {
		this.total_fees = total_fees;
	}
	public Date getLast_payment_date() {
		return last_payment_date;
	}
	public void setLast_payment_date(Date last_payment_date) {
		this.last_payment_date = last_payment_date;
	}
	public Double getFine() {
		return fine;
	}
	public void setFine(Double fine) {
		this.fine = fine;
	}
	public Double getTotal_amount() {
		return total_amount;
	}
	public void setTotal_amount(Double total_amount) {
		this.total_amount = total_amount;
	}
	@Override
	public String toString() {
		return "Payment_master [student_id=" + student_id + ", balance="
				+ balance + ", total_fees=" + total_fees
				+ ", last_payment_date=" + last_payment_date + ", fine=" + fine
				+ ", total_amount=" + total_amount + "]";
	}
	
	
}

