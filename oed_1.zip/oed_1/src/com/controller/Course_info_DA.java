package com.controller;


import java.sql.*;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.*;
import java.text.*;
import java.util.concurrent.ExecutionException;
public class Course_info_DA {
private static Connection con;
private static Statement stmt;
private static ResultSet rs;

//static String i1sqlj="insert into customer value(?,?,?,?,?)";

static PreparedStatement ps=null;

public static List<Course_info> getcourse_info()
{
try{
		
		String url ="jdbc:mysql://localhost:3306/onlineeductionalportal";
		Class.forName("com.mysql.jdbc.Driver");
		con =DriverManager.getConnection(url,"root","root");
		stmt= con.createStatement();
	}catch(Exception ex){
	System.out.println("Open Exception-Course_info");	
	}
	List<Course_info>local =new ArrayList<>();
	try{
		String query ="Select * from course_info";
		rs=stmt.executeQuery(query);
		
		while(rs.next())
		{
			 String course_id=rs.getString(1);   
			 String course_name=rs.getString(2); 
			 Integer period=rs.getInt(3);     
			 Double course_fees=rs.getDouble(4); 
			     
		local.add(new Course_info(course_id, course_name, period, course_fees));
		}
	}catch(Exception ex){
		System.out.println(ex);
	}
	try{
		con.close();
	}catch(Exception ex)
	{
		System.out.println("Closing Exception-Course_info");
	}finally
	{
		try{
			con.close();
		}catch(Exception ex)
		{
			System.out.println("Closing Exception-get_teacher_info");
		}
	
	}
	return local;
}


public static int insertcourse_info(Course_info c)
{
try{
		
		String url ="jdbc:mysql://localhost:3306/onlineeductionalportal";
		Class.forName("com.mysql.jdbc.Driver");
		con =DriverManager.getConnection(url,"root","root");
		stmt= con.createStatement();
	}catch(Exception ex){
	System.out.println("Open Exception-Course_info");	
	}
	String i1sqlj="insert into course_info value(?,?,?,?)";
	int r=0;
	
	try{
		ps=con.prepareStatement(i1sqlj);
		ps.setString(1, c.getCourse_id());
		ps.setString(2, c.getCourse_name());
		ps.setInt(3, c.getPeriod());
		ps.setDouble(4, c.getCourse_fees());
		r=ps.executeUpdate();
		
	}catch(Exception ex)
	{
		System.out.println(ex);
	}finally
	{
	try{
		con.close();
	}catch(Exception ex)
	{
		System.out.println("Closing Exception-Course_info");
	}
	}
	return r;
	
}


}
