package com.controller;

import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.util.*;
import java.util.logging.ConsoleHandler;
import java.util.logging.FileHandler;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Payment
 */
@WebServlet("/Payment")
public class Payment extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	 private static Logger log = Logger.getLogger(Payment.class.getName());
	    @Override
	    public void init() throws ServletException 
	{
	          log.setLevel(Level.FINE);
	          log.addHandler(new ConsoleHandler());
	          try {
	               File dir = new File("D:\\Logs");
	               if(!dir.exists())
	               {
	                    dir.mkdir();
	               }
	               
	               File file = new File(dir,"logger.payment");
	               Handler fileHandler = new FileHandler(file.getAbsolutePath(), 2000, 5);
	               log.addHandler(fileHandler);
	       } catch (SecurityException | IOException e1) {
	           System.out.println("Exception on creating log file");
	          e1.printStackTrace();
	    }
	}

	static HttpSession ses=null;
	static int student_id;
	static java.util.Date last_pay;
	static double fine;
	static double total_amount;
	static double total_fees;
	static double balance;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Payment() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
	     balance= balance-total_amount;
		Date reg_date=last_pay;
		Date last_payment_date= new Date();
		Date payment_date=last_payment_date;
	
		Payment_master pm=new Payment_master(student_id, balance, total_fees, last_payment_date, fine, total_amount);
		Payment_master_DAO.updatepayment_master(pm);
		

		List<Payment_info> plist=Payment_info_DAO.getPayment_info();
		List<Integer> idlist=new ArrayList<>();
		

		int n=1;
		if(plist.isEmpty());
		else
		{
			for(Payment_info x:plist)
			{
			idlist.add(x.getPayment_id());
			}
			java.util.Collections.sort(idlist);
			n=idlist.get(idlist.size()-1)+1;
		}
		int payment_id=n;        
		
		int payment_for=Payment_info_DAO.calculatesem(reg_date);

		
		Payment_info pi=new Payment_info(payment_id, student_id, payment_for, payment_date);
		int i=Payment_info_DAO.insertpayment_info(pi);
	
		
		
		String msg="";
		if(i==1)
			msg="<h1><font color='green'> Payment details has been successfully inserted </font></h1>";
		else
			msg="<h1><font color='red'> Payment details not inserted </font> </h1>";
		
		log.warning(msg);
		ses.setAttribute("msg1",msg);
	     RequestDispatcher rd= request.getRequestDispatcher("end1.jsp");
		  rd.forward(request, response);
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 student_id=Integer.parseInt(request.getParameter("student_id"));
		List<Student_info> slist=Student_info_DAO.getStudent_info();
		List<Course_info> clist=Course_info_DA.getcourse_info();
		List<Payment_master> plist=Payment_master_DAO.getpayment_master();
		List<Payment_info> pilist=Payment_info_DAO.getPayment_info();
		
		String course_name=null;
		Student_info s=null;
		Payment_master p=null;
		
		for(Student_info x: slist)
		{
			if(student_id==(int)x.getStudent_id())
				{ 
				 s=x; 
				 break;
				}
		}
	

		for(Course_info x: clist)
		{
			if(s.getCourse_id().equals(x.getCourse_id()))
			{
				course_name=x.getCourse_name();
			}
			
		}	
		
		for(Payment_master x: plist)
		{
			if(x.getStudent_id()==(int) student_id)
			{
				p=x;
				break;
			}
		}
		
		
		String student_name=s.getStudent_name();
		String s_mode=s.getMode_of_payment();
		double fee=p.getTotal_fees();
	   	double fee1=p.getTotal_amount();
		 last_pay= p.getLast_payment_date();
		 double fd=0.0;
		try {
			fd = Payment_master_DAO.finecal(last_pay, s_mode);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		 fine=fd*100;
		
		 total_fees=fee;
		 
		 total_amount=fee1;
		
		 balance=fee;
		 
	  ses=request.getSession();
	  
	  ses.setAttribute("s_id", student_id);
	  ses.setAttribute("s_name", student_name);
	  ses.setAttribute("stream", course_name);
	  ses.setAttribute("fees", fee+"");
	  ses.setAttribute("semfee", fee1+"");
	  ses.setAttribute("fine", fine+"");
	  ses.setAttribute("total", (total_amount+fine)+"");
     RequestDispatcher rd= request.getRequestDispatcher("payment.jsp");
	  rd.forward(request, response);
	
}

}
