package com.controller;

public class Course_info 
{
	private String course_id;
	private String course_name;
	private Integer period; 
	private Double course_fees;
	public Course_info(String course_id, String course_name, Integer period,
			Double course_fees) {
		super();
		this.course_id = course_id;
		this.course_name = course_name;
		this.period = period;
		this.course_fees = course_fees;
		new Course_info_DA();
	}
	public Course_info() {
		super();
		// TODO Auto-generated constructor stub
		new Course_info_DA();
	}
	public String getCourse_id() {
		return course_id;
	}
	public void setCourse_id(String course_id) {
		this.course_id = course_id;
		new Course_info_DA();
	}
	public String getCourse_name() {
		return course_name;
	}
	public void setCourse_name(String course_name) {
		this.course_name = course_name;
		new Course_info_DA();
	}
	public Integer getPeriod() {
		return period;
	}
	public void setPeriod(Integer period) {
		this.period = period;
		new Course_info_DA();
	}
	public Double getCourse_fees() {
		return course_fees;
	}
	public void setCourse_fees(Double course_fees) {
		this.course_fees = course_fees;
		new Course_info_DA();
	}
	public static void main(String[] args) {
		
	}
	
	
	
}

