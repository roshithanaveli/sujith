package com.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.controller.Admin_info;

/**
 * Servlet Filter implementation class OEPFilter
 */
@WebFilter({ "/OEPFilter", "*.jsp", "*.do" })
public class OEPFilter implements Filter {

    /**
     * Default constructor. 
     */
    public OEPFilter() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// TODO Auto-generated method stub
		// place your code here

		// pass the request along the filter chain
		
		
		HttpServletRequest hrequest = (HttpServletRequest) request;
        HttpSession ses = hrequest.getSession();
//     String obj = (String) ses.getAttribute("sug");   
     Admin_info obj = (Admin_info) ses.getAttribute("suji");                    

           System.out.println(obj);
        
        String path = hrequest.getRequestURI().substring(hrequest.getContextPath().length()).replaceAll("[/]+$", ""); 
        
        System.out.println("Path: " + path);
        
            
        if(obj==null &&  !(path.equals("")))
        {
            request.setAttribute("errmsg1", "<font color=red>Login to access the features</font>");
            System.err.println("====================================================");
            System.err.println("Unauthorized access recorded: " + new java.util.Date());
            System.err.println("====================================================");
            RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
            rd.forward(request, response);
        }
        else
        {
            chain.doFilter(request, response);
        }
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
